#! /usr/bin/env bash
RED="31"
GREEN="32"
BOLDGREEN="\e[1;${GREEN}m"
ITALICRED="\e[3;${RED}m"
ENDCOLOR="\e[0m"
YELLOW="\e[33m"
BLUE="\e[34m"
CYAN="\e[36m"
MAGENTA="\e[35m"
RED="\e[41m"
WHITE="\e[97m"
BLACK="\e[30m"
BOLDCYAN="\e[36m"
echo""
echo""
echo""
echo -e $'\e[1;31m      \e[1;31m 
                            ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░
                            ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀
                            ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░\e[0m'
echo -e "      \e[1;31m                      %${BOLDGREEN}░█████╗░░░░░░░░██████╗████████╗███████╗░█████╗░██╗░░░░░███████╗██████╗░\e[1;31m%                    ${ENDCOLOR}"
echo -e "      \e[1;31m                      %${BOLDGREEN}██╔══██╗░░░░░░██╔════╝╚══██╔══╝██╔════╝██╔══██╗██║░░░░░██╔════╝██╔══██╗\e[1;31m%                    ${ENDCOLOR}"
echo -e "      \e[1;31m                      %${BOLDGREEN}██║░░╚═╝█████╗╚█████╗░░░░██║░░░█████╗░░███████║██║░░░░░█████╗░░██████╔╝\e[1;31m%                    ${ENDCOLOR}"
echo -e "      \e[1;31m                      %${BOLDGREEN}██║░░██╗╚════╝░╚═══██╗░░░██║░░░██╔══╝░░██╔══██║██║░░░░░██╔══╝░░██╔══██╗\e[1;31m%                    ${ENDCOLOR}"
echo -e "      \e[1;31m                      %${BOLDGREEN}╚█████╔╝░░░░░░██████╔╝░░░██║░░░███████╗██║░░██║███████╗███████╗██║░░██║\e[1;31m%                    ${ENDCOLOR}"
echo -e "      \e[1;31m                      %${BOLDGREEN}░╚════╝░░░░░░░╚═════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚══════╝╚══════╝╚═╝░░╚═╝\e[1;31m%                   ${ENDCOLOR}"
echo -e "      \e[1;31m                      ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░
                            ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀▀ ▀ 
                            ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░░ ░\e[0m ${ENDCOLOR}"
echo""
echo""
banner() {
echo -e "${ITALICRED}              Created By xploitpoison.sh${ENDCOLOR}"
echo""
echo""
echo""
echo""
echo""
echo -e $'\e[1;36m      \e[1;36mC-STEALER Tool\e[0m'
echo -e $'\e[1;36m      \e[1;36mCredit Card/Debit Card Stealer Tool.\e[0m'
echo""
echo -e $'\e[1;36m      \e[1;36mSteal Credit Card\e[0m'
echo -e $'\e[1;36m      \e[1;36mSteal Debit Card \e[0m'
echo -e $'\e[1;36m      \e[1;36mBypass OTP \e[0m'
echo""
echo""

echo""
echo""
echo -e $'\e[1;31m         \e[1;31m.......................................................................\e[0m'
echo -e "      \e[1;31m   | Website -${BOLDGREEN}                https://www.xploitpoison.com\e[1;31m               |${ENDCOLOR}"
echo -e "      \e[1;31m   | Telegram-${BOLDGREEN}                https://t.me/leakedcontents \e[1;31m               |${ENDCOLOR}"
echo -e "      \e[1;31m   | WhatsApp-${BOLDGREEN}                https://wa.me/918252422648 \e[1;31m                |${ENDCOLOR}"
echo -e "      \e[1;31m   | Instagram  -${BOLDGREEN}             https://instagram.com/xploitpoison \e[1;31m        |${ENDCOLOR}"
echo -e "      \e[1;31m   | Premium Package -${BOLDGREEN}        https://premium-xploitpoison.blogspot.com/ \e[1;31m|${ENDCOLOR}"
echo -e $'\e[1;31m         \e[1;31m.......................................................................\e[0m'
echo -e $'\e[1;33m                                                                  FREE VERSION\e[1;31m✔   \e[0m'
echo""
echo""
echo -e $'\e[1;32m  ◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶  \e[0m'
echo -e $'\e[1;33m           Created BY -:        \e[1;34mXploit Poison\e[1;32m✔   \e[0m'
echo -e $'\e[1;32m  ◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶  \e[0m'
echo""
echo""
echo""
echo""
echo -e $'\e[1;31m    📵 Disclaimer  \e[1;41m -\e[1;97m   Use This Tool only For Education Purpose. \e[0m'

echo""
echo""
}
      banner
